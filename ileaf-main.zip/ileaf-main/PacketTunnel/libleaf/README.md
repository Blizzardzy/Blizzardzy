Run the `misc/download_leaf.sh` script to download library files.
